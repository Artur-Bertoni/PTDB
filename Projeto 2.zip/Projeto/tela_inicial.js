const videos = [
    {
        id: 1,
        titulo: "Introdução à Programação",
        descricao: "Conteúdo introdutório sobre lógica de programação.",
        categoria: "Tecnologia",
        arquivo: ""
    },
    {
        id: 2,
        titulo: "Matemática Básica",
        descricao: "Operações fundamentais e conceitos matemáticos.",
        categoria: "Educação",
        arquivo: ""
    },
    {
        id: 3,
        titulo: "Banco de Dados",
        descricao: "Introdução à modelagem de dados e SQL.",
        categoria: "Tecnologia",
        arquivo: ""
    },
    {
        id: 4,
        titulo: "Engenharia de Software",
        descricao: "Metodologias e processos de desenvolvimento.",
        categoria: "Tecnologia",
        arquivo: ""
    },
    {
        id: 5,
        titulo: "Algoritmos",
        descricao: "Estruturas de controle e resolução de problemas.",
        categoria: "Tecnologia",
        arquivo: ""
    },
    {
        id: 6,
        titulo: "Redes de Computadores",
        descricao: "Fundamentos de comunicação e redes.",
        categoria: "Tecnologia",
        arquivo: ""
    },
    {
        id: 7,
        titulo: "Gestão de Projetos",
        descricao: "Planejamento e gerenciamento de equipes.",
        categoria: "Educação",
        arquivo: ""
    },
    {
        id: 8,
        titulo: "Segurança da Informação",
        descricao: "Boas práticas para proteção de dados.",
        categoria: "Tecnologia",
        arquivo: ""
    },
    {
        id: 9,
        titulo: "Desenvolvimento Web",
        descricao: "Criação de aplicações utilizando HTML, CSS e JavaScript.",
        categoria: "Tecnologia",
        arquivo: ""
    }
];

const listaVideos =
document.getElementById("listaVideos");

const pesquisa =
document.getElementById("pesquisa");

const filtroCategoria =
document.getElementById("filtroCategoria");

const btnLogin =
document.getElementById("btnLogin");

const btnSair =
document.getElementById("btnSair");

const btnGerenciar =
document.getElementById("btnGerenciar");

/* USUÁRIO LOGADO */

const usuario =
JSON.parse(
    localStorage.getItem("usuario")
);

/* BLOQUEIA ACESSO SEM LOGIN */

if (!usuario) {

    window.location.href =
    "tela_login.html";

}

/* EXIBE NOME DO USUÁRIO */

const usuarioLogado =
document.getElementById("usuarioLogado");

if (
    usuarioLogado &&
    usuario
) {

   usuarioLogado.textContent =
`${usuario.nome} (${usuario.tipoUsuario})`;

}

/* SOMENTE ADMINISTRADOR */

if (
    usuario.tipoUsuario !==
    "administrador"
) {

    btnGerenciar.style.display =
    "none";

}
btnLogin.style.display =
"none";

function carregarVideos() {

    listaVideos.innerHTML = "";

    const textoPesquisa =
    pesquisa.value.toLowerCase();

    const categoriaSelecionada =
    filtroCategoria.value;

    const videosFiltrados =
    videos.filter(video => {

        const tituloMatch =
        video.titulo
        .toLowerCase()
        .includes(textoPesquisa);

        const categoriaMatch =
        categoriaSelecionada === "" ||
        video.categoria === categoriaSelecionada;

        return tituloMatch &&
        categoriaMatch;

    });

    videosFiltrados.forEach(video => {

        const card =
        document.createElement("div");

        card.classList.add("video-card");

        card.innerHTML = `
            <h3>${video.titulo}</h3>

            <p class="descricao">
                ${video.descricao}
            </p>

            <p class="categoria">
                Categoria: ${video.categoria}
            </p>

            ${
                video.arquivo !== ""
                ?
                `
                <video controls>
                    <source src="${video.arquivo}">
                </video>
                `
                :
                `
                <div class="area-vazia">

                    <div class="icone-video">
                        📹
                    </div>

                    <p>
                        Área reservada para vídeo
                    </p>

                    <small>
                        O vídeo será exibido aqui
                    </small>

                </div>
                `
            }
        `;

        listaVideos.appendChild(card);

    });

}

/* PESQUISA */

pesquisa.addEventListener(
    "input",
    carregarVideos
);

/* FILTRO */

filtroCategoria.addEventListener(
    "change",
    carregarVideos
);

/* LOGIN */

btnLogin.addEventListener(
    "click",
    () => {

        window.location.href =
        "tela_login.html";

    }
);

/* SAIR */

btnSair.addEventListener(
    "click",
    () => {

        localStorage.clear();

        window.location.href =
        "tela_login.html";

    }
);

carregarVideos();