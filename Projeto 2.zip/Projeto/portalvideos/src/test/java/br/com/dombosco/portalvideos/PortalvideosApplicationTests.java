package br.com.dombosco.portalvideos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalvideosApplicationTests {

	@Test
	void contextLoads() {
	}

}
