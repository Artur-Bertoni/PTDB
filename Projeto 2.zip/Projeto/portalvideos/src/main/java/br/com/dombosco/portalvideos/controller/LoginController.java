package br.com.dombosco.portalvideos.controller;

import br.com.dombosco.portalvideos.dto.LoginRequest;
import br.com.dombosco.portalvideos.entity.Usuario;
import br.com.dombosco.portalvideos.service.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/login")
@CrossOrigin("*")
public class LoginController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping
    public ResponseEntity<?> login(
            @RequestBody LoginRequest request
    ) {

        Optional<Usuario> usuario =
                usuarioService.login(
                        request.getUsuario(),
                        request.getSenha()
                );

        if (usuario.isEmpty()) {

            return ResponseEntity
                    .badRequest()
                    .body("Usuário ou senha inválidos");

        }

        return ResponseEntity.ok(
                usuario.get()
        );

    }

}