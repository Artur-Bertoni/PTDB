package br.com.dombosco.portalvideos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortalvideosApplication {

    public static void main(String[] args) {

        SpringApplication.run(
                PortalvideosApplication.class,
                args
        );

    }
}