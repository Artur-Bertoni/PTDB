package br.com.dombosco.portalvideos.service;

import br.com.dombosco.portalvideos.entity.Video;
import br.com.dombosco.portalvideos.repository.VideoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideoService {

    @Autowired
    private VideoRepository videoRepository;

    public List<Video> listarTodos() {

        return videoRepository.findAll();

    }

}