package br.com.dombosco.portalvideos.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "video")
public class Video {

    @Id
    @Column(name = "id_video")
    private Long idVideo;

    private String titulo;

    private String arquivo;

    private String capa;

    @Column(name = "qtd_views")
    private Integer qtdViews;

    @Column(name = "data_publicacao")
    private LocalDate dataPublicacao;

    public Video() {
    }

    public Long getIdVideo() {
        return idVideo;
    }

    public void setIdVideo(Long idVideo) {
        this.idVideo = idVideo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getArquivo() {
        return arquivo;
    }

    public void setArquivo(String arquivo) {
        this.arquivo = arquivo;
    }

    public String getCapa() {
        return capa;
    }

    public void setCapa(String capa) {
        this.capa = capa;
    }

    public Integer getQtdViews() {
        return qtdViews;
    }

    public void setQtdViews(Integer qtdViews) {
        this.qtdViews = qtdViews;
    }

    public LocalDate getDataPublicacao() {
        return dataPublicacao;
    }

    public void setDataPublicacao(LocalDate dataPublicacao) {
        this.dataPublicacao = dataPublicacao;
    }
}