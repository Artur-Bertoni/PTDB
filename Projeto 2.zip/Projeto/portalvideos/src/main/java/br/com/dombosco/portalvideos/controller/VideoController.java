package br.com.dombosco.portalvideos.controller;

import br.com.dombosco.portalvideos.entity.Video;
import br.com.dombosco.portalvideos.service.VideoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/videos")
@CrossOrigin("*")
public class VideoController {

    @Autowired
    private VideoService videoService;

    @GetMapping
    public List<Video> listarVideos() {

        return videoService.listarTodos();

    }

}