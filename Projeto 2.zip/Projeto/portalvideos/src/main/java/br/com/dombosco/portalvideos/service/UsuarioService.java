package br.com.dombosco.portalvideos.service;

import br.com.dombosco.portalvideos.entity.Usuario;
import br.com.dombosco.portalvideos.repository.UsuarioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Optional<Usuario> buscarPorMatricula(String matricula) {

        return usuarioRepository.findByMatricula(matricula);

    }

    public Optional<Usuario> buscarPorEmail(String email) {

        return usuarioRepository.findByEmail(email);

    }

    public Optional<Usuario> login(
            String usuario,
            String senha
    ) {

        Optional<Usuario> usuarioBanco =
                usuarioRepository.findByMatricula(usuario);

        if (
                usuarioBanco.isPresent()
                        && usuarioBanco.get()
                        .getSenha()
                        .equals(senha)
        ) {

            return usuarioBanco;

        }

        usuarioBanco =
                usuarioRepository.findByEmail(usuario);

        if (
                usuarioBanco.isPresent()
                        && usuarioBanco.get()
                        .getSenha()
                        .equals(senha)
        ) {

            return usuarioBanco;

        }

        return Optional.empty();

    }

}