const loginForm =
document.getElementById("loginForm");

const usuarioInput =
document.getElementById("usuario");

const senhaInput =
document.getElementById("senha");

const forgotPassword =
document.getElementById("forgotPassword");

const confirmReset =
document.getElementById("confirmReset");

const btnSim =
document.getElementById("btnSim");

const btnNao =
document.getElementById("btnNao");

const message =
document.getElementById("message");

const mostrarSenha =
document.getElementById("mostrarSenha");

confirmReset.style.display = "none";

/* LOGIN */
loginForm.addEventListener(
    "submit",
    async function(event){

        event.preventDefault();

        const usuario =
        usuarioInput.value.trim();

        const senha =
        senhaInput.value.trim();

        try {

            const resposta =
            await fetch(
                "http://localhost:8080/login",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({

                        usuario,
                        senha

                    })
                }
);

            if(!resposta.ok){

                message.textContent =
                "Usuário ou senha inválidos.";

                message.style.color =
                "red";

                return;

            }

            const dados =
            await resposta.json();

            localStorage.setItem(
                "tipoUsuario",
                dados.tipoUsuario
            );

            localStorage.setItem(
                "usuario",
                JSON.stringify(dados)
            );

            message.textContent =
            "Login realizado com sucesso!";

            message.style.color =
            "green";

            setTimeout(() => {

                window.location.href =
                "tela_inicial.html";

            },1000);

        }
        catch(erro){

            message.textContent =
            "Erro ao conectar com a API.";

            message.style.color =
            "red";

            console.log(erro);

        }

    }
);
/* ESQUECEU SENHA */

forgotPassword.addEventListener(
    "click",
    function (event) {

        event.preventDefault();

        confirmReset.style.display =
        "flex";

        message.textContent = "";

    }
);

/* BOTÃO SIM */

btnSim.addEventListener(
    "click",
    function () {

        message.textContent =
        "Solicitação enviada com sucesso!";

        message.style.color =
        "green";

        confirmReset.style.display =
        "none";

    }
);

/* BOTÃO NÃO */

btnNao.addEventListener(
    "click",
    function () {

        confirmReset.style.display =
        "none";

        message.textContent = "";

    }
);

/* MOSTRAR SENHA */

mostrarSenha.addEventListener(
    "click",
    () => {

        if (
            senhaInput.type === "password"
        ) {

            senhaInput.type =
            "text";

            mostrarSenha.textContent =
            "🙈";

        } else {

            senhaInput.type =
            "password";

            mostrarSenha.textContent =
            "👁";

        }

    }
);